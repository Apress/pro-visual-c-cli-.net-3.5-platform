========================================================================
    WEB SERVICE : [!output PROJECT_NAME] Project Overview
========================================================================

AppWizard has created this [!output PROJECT_NAME] project for you.  

This file contains a summary of what you will find in each of the files that
make up your [!output PROJECT_NAME] application.

[!output PROJECT_NAME].vcproj
    This is the main project file for VC++ projects generated using an Application Wizard. 
    It contains information about the version of Visual C++ that generated the file, and 
    information about the platforms, configurations, and project features selected with the
    Application Wizard.

[!output PROJECT_NAME]Class.cpp
    This is the main web source file.

[!output PROJECT_NAME]Class.h
    This header file contains the declarations of the Web Service.

AssemblyInfo.cpp
	Contains custom attributes for modifying assembly metadata.


Web.Config
    This file allows you to override the default configuration settings for your service. 
    Web Services use the configuration file to allow customization and extensibility of the system. 
    You might supply a Web Service specific Web.Config file, for instance, if your Web Service 
    requires authentication and other Web Applications on the system do not.

/////////////////////////////////////////////////////////////////////////////
Other notes:

AppWizard uses "TODO:" to indicate parts of the source code you
should add to or customize.

/////////////////////////////////////////////////////////////////////////////
