// [!output PROJECT_NAME].asmx.cpp : main project file.

#include "stdafx.h"
#include "[!output PROJECT_NAME].asmx.h"

[!output SAFE_NAMESPACE_BEGIN]

	[! output SAFE_NAMESPACE_NAME]Class::[! output SAFE_NAMESPACE_NAME]Class()
	{
		//
		//TODO: Add the constructor code here
		//
	}

	[! output SAFE_NAMESPACE_NAME]Class::~[! output SAFE_NAMESPACE_NAME]Class()
	{
		//
		//TODO: Add the destructor code here
		//
	}
    
    String^ [!output SAFE_NAMESPACE_NAME]Class::HelloWorld()
    {
		//
		// TODO: Add the implementation of your Web Service here
		//
		return L"Hello World!";
    }

[!output SAFE_NAMESPACE_END]
