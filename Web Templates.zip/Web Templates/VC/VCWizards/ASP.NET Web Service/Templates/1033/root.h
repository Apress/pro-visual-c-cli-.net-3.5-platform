// [!output SAFE_NAMESPACE_NAME].asmx.h

#pragma once

using namespace System;
using namespace System::Web;
using namespace System::Web::Services;

[!output SAFE_NAMESPACE_BEGIN]
	[WebServiceBinding(ConformsTo=WsiProfiles::BasicProfile1_1,EmitConformanceClaims = true)]
	[WebService(Namespace="TODO: Enter Unique URL", Description = "TODO: Enter Description")]
    public ref class [! output SAFE_NAMESPACE_NAME]Class : public System::Web::Services::WebService
    {
    public:
		/// <summary>
		/// Default Constructor
		/// </summary>
		[! output SAFE_NAMESPACE_NAME]Class();

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~[! output SAFE_NAMESPACE_NAME]Class();

	public:
		/// <summary>
		/// "Hello World!" Web Service example
		/// </summary>
		/// <returns>
		/// The string "Hello, World!".
		/// </returns>
		/// <remarks>
		/// To test this web service, ensure that the .asmx file in the Startup Project is
		/// set as your Startup Page and press F5.
		/// </remarks>
        [System::Web::Services::WebMethod]
        String ^HelloWorld();

        // TODO: Add the methods of your Web Service here
	};
[!output SAFE_NAMESPACE_END]
