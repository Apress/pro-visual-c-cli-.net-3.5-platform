// [!output SAFE_ITEM_NAME].aspx.cpp : main project file.

[!if PCH]
#include "[!output PCH_NAME]"
[!endif]
#include "[!output SAFE_ITEM_NAME].aspx.h"


[!output SAFE_NAMESPACE_BEGIN]
    void [!output SAFE_ITEM_NAME]::Page_Load(Object ^sender, EventArgs ^e)
    {
    }

[!output SAFE_NAMESPACE_END]

