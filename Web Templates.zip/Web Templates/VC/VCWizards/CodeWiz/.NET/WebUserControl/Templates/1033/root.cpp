// [!output SAFE_ITEM_NAME].aspx.cpp : main project file.

[!if PCH]
#include "[!output PCH_NAME]"
[!endif]
#include "[!output SAFE_ITEM_NAME].ascx.h"


[!output SAFE_NAMESPACE_BEGIN]
	namespace uc
	{
		void [!output SAFE_ITEM_NAME]::Page_Load(Object ^sender, EventArgs ^e)
		{
			//
			// TODO: Add the implementation of your Web Page here
			//
			Response->Write (L"<h1>Hello World</h1>");
		}
	}
[!output SAFE_NAMESPACE_END]

