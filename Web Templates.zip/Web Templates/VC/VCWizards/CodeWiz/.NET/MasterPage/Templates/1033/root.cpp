// [!output SAFE_ITEM_NAME].master.cpp : main project file.

[!if PCH]
#include "[!output PCH_NAME]"
[!endif]
#include "[!output SAFE_ITEM_NAME].master.h"


[!output SAFE_NAMESPACE_BEGIN]
    void [!output SAFE_ITEM_NAME]::Page_Load(Object ^sender, EventArgs ^e)
    {
		//
		// TODO: Add the implementation of your MasterPage here
		//
    }

[!output SAFE_NAMESPACE_END]

