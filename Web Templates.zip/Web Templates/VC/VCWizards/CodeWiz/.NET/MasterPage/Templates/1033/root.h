// [!output SAFE_ITEM_NAME].master.h

#pragma once

using namespace System;
using namespace System::Collections;
using namespace System::Configuration;
using namespace System::Data;
using namespace System::Web;
using namespace System::Web::Security;
using namespace System::Web::UI;
using namespace System::Web::UI::HtmlControls;
using namespace System::Web::UI::WebControls;
using namespace System::Web::UI::WebControls::WebParts;
using namespace System::Xml;

[!output SAFE_NAMESPACE_BEGIN]
public ref class [!output SAFE_ITEM_NAME] : public System::Web::UI::MasterPage
	{
	protected:
		void Page_Load(Object ^sender, EventArgs ^e);
	};
[!output SAFE_NAMESPACE_END]
