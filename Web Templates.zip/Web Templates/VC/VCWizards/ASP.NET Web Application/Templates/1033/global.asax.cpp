#include "stdafx.h"
#include "Global.asax.h"

[!output SAFE_NAMESPACE_BEGIN] 
	void Global::Application_Start(Object ^sender, EventArgs ^e)
    {

    }

	void Global::Session_Start(Object ^sender, EventArgs ^e)
    {

    }

    void Global::Application_BeginRequest(Object ^sender, EventArgs ^e)
    {

    }

	void Global::Application_EndRequest(Object ^sender, EventArgs ^e)
    {

    }

    void Global::Session_End(Object ^sender, EventArgs ^e)
    {

    }

    void Global::Application_End(Object ^sender, EventArgs ^e)
    {

    }
[!output SAFE_NAMESPACE_END]
