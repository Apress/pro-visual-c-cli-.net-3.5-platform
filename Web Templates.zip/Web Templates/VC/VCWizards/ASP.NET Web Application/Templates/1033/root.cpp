// [!output PROJECT_NAME].aspx.cpp : main project file.

#include "stdafx.h"
#include "[!output PROJECT_NAME].aspx.h"

[!output SAFE_NAMESPACE_BEGIN]
    void _Default::Page_Load(Object ^sender, EventArgs ^e)
    {
		//
		// TODO: Add the implementation of your Web Page here
		//
		Response->Write (L"<h1>Hello World</h1>");
    }

[!output SAFE_NAMESPACE_END]

